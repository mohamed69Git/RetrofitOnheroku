<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TypeRepasController extends Controller
{
    //
}
